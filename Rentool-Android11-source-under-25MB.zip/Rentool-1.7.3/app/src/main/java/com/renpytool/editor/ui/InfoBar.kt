package com.renpytool.editor.ui

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme.colorScheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun InfoBar(subtitle: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(24.dp)
            .background(color = colorScheme.surfaceContainer),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Spacer(modifier = Modifier.padding(start = 16.dp))
        Text(
            modifier = Modifier
                .alpha(0.65f)
                .animateContentSize(),
            text = subtitle,
            fontSize = 10.sp,
            color = colorScheme.onSurface
        )
        Spacer(modifier = Modifier.weight(1f))
        Text(
            modifier = Modifier
                .alpha(0.65f)
                .animateContentSize(),
            text = "UTF-8",
            fontSize = 10.sp,
            color = colorScheme.onSurface
        )
        Spacer(modifier = Modifier.padding(end = 16.dp))
    }
}
